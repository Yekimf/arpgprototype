The Forgotten Kingdom — editable weapon grip sprite sheets

32 transparent PNGs: one for each of 16 weapons and two character models.
Every sheet is 1728 × 2816 pixels, arranged as 16 direction rows and 9 animation columns.
Each cell is 192 × 176 pixels. Row 0 faces north (rear); row 8 faces south (front).
Column 0 is idle. Columns 1–8 are the eight attack frames.
manifest.json gives the weapon names and exact hand and hilt anchors in each cell.
The two weapon-models comparison images show the current game's front and rear idle poses; they are not the supplied reference paintings.

These are exports of the current layered renderer, not pixel-exact copies of the supplied front/rear references. Editing a PNG does not yet change the game automatically; send back the edited sheets or cells to integrate them. The original source atlases are also included.
